import os


cases=['Buffer50','Buffer100','Buffer150','PolB50','PolB100','PolB150']
#cases=['allData']

#cases=['Pol','PolB50','PolB100','PolB150']

#cases=['PolB100']
cases=['PolB50','PolB100','PolB150','Buffer50','Buffer100','Buffer150']

#cases=['PolB100']
#'Buffer100'
path='/Users/paguirre/drive/[Research]/Fondecyt1191543/incendiosForestales/analisisEstadistico/'

#option='eda_cli.py'
option='main.py'

for case in cases:
    inpath='%s/wfm_input_paa_ndvi/%s'%(path,case)
    outpath='%s/wfm_output_ndvi/%s'%(path,case)
    cmd='python %s --input_path %s --output_path %s'%(option,inpath,outpath)
    print(cmd)
    os.system(cmd)
