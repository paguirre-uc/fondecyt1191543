import logging,pickle
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import lightgbm as lgb
import shap
import h5py

from joblib import dump
from sklearn.model_selection import train_test_split, cross_validate, RepeatedStratifiedKFold
from sklearn.metrics import classification_report, make_scorer, jaccard_score

from wfm.utils import get_display_and_numeric_data, _recall, recall,_accuracy
from wfm.constants import TARGET_COLUMN, SPANISH_NAMES,X_MAP,X_COLUMNS


logger = logging.getLogger(__name__)


def model_and_explanation(
    input_data,
    model_parameters,
    output_path,
    images_path,
    test_size=0.25,
    split_random_state=42,
    model_random_state=42,
):

    logger.info("Getting and spliting data.")
    # --- Design matrix and target vector ---


    X_display, y_display, X, y = get_display_and_numeric_data(
        input_data,
        X_COLUMNS,
        TARGET_COLUMN,
    )
    # --- Split Data ---
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=test_size,
        random_state=split_random_state
    )

    # --- LightGBM Model  ---
    logger.info("Fitting the model.")
    model = lgb.LGBMClassifier(**model_parameters, random_state=model_random_state)
    _ = model.fit(
        X_train,
        y_train,
        eval_set=[(X_test, y_test)],
        eval_metric=recall,

    )
    dump(model, output_path / "model.joblib")

    # --- Model Evaluation  ---
    logger.info("Classification Report.")
    y_pred = model.predict(X_test)
    logger.info("\n" +
        classification_report(
            y_test,
            y_pred,
        )
    )
    cross_validation_summary(model, X, y, images_path)

    # --- Model Explanation ---
    logger.info("Model Explanation using Shap values.")
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X)
    with h5py.File(output_path / "shap_values.h5", 'w') as hf:
        hf.create_dataset("shap_values",  data=shap_values)
    # Summary Plot
    summary_plot(X, model, shap_values, images_path)
    # Dependence Plots
    dependence_plot(X, X_display, model, shap_values, images_path)

    return X_display, y_display, X, y, model, shap_values


def group_model_and_explanation(
    input_data,
    model_parameters,
    output_path,
    images_path,
    model_random_state=42,
):
    # --- Design matrix and target vector ---
    X_display, y_display, X, y = get_display_and_numeric_data(
        input_data,
        X_COLUMNS + ["wildfire"],
        TARGET_COLUMN,
    )
    metrics_file = output_path / f"wildfire_batch_metrics.txt"
    print(metrics_file)
    if metrics_file.exists():
        metrics_file.unlink()
    for wildfire in X_display["wildfire"].unique():
        wildfire_images_path = images_path / wildfire
        wildfire_images_path.mkdir(parents=True, exist_ok=True)
        logger.info(f"Model using {wildfire} as test set.")
        wildfire_mask = X_display["wildfire"].eq(wildfire)
        X_train = X.loc[~wildfire_mask, :].drop(columns=["wildfire"])
        y_train = y[~wildfire_mask]
        X_test = X.loc[wildfire_mask, :].drop(columns=["wildfire"])
        y_test = y[wildfire_mask]

        model = lgb.LGBMClassifier(**model_parameters, random_state=model_random_state)
        _ = model.fit(
            X_train,
            y_train,
            eval_set=[(X_test, y_test)],
            eval_metric=recall,

        )
        # --- Model Evaluation  ---
        train_classification_report = classification_report(
            y_train,
            model.predict(X_train),
        )
        test_classification_report = classification_report(
            y_test,
            model.predict(X_test),
        )
        
        
        with open(metrics_file, "a") as f:
            f.write("#" * 80)
            f.write(f"\n{wildfire} as test set\n")
            f.write("#" * 80)
            f.write("\n\nTrain classification report\n\n")
            f.write(train_classification_report)
            f.write("\n\nTest classification report\n\n")
            f.write(test_classification_report)
            f.write("\n")

        # --- Model Explanation ---
        explainer = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(X.drop(columns=["wildfire"]))
        # Summary Plot
        summary_plot(
            X.drop(columns=["wildfire"]),
            model,
            shap_values,
            wildfire_images_path
        )
        # Dependence Plots
        dependence_plot(
            X.drop(columns=["wildfire"]),
            X_display.drop(columns=["wildfire"]),
            model,
            shap_values,
            wildfire_images_path
        )


def cross_validation_summary(model, X, y, images_path):
    recall_score = make_scorer(_recall, greater_is_better=True)
    accuracy_score = make_scorer(_accuracy, greater_is_better=True)
    jaccard_scorer = make_scorer(jaccard_score, greater_is_better=True)
    scores={'recall':recall_score,'accuracy':accuracy_score}


    cv_model = cross_validate(model,X,y,scoring=recall_score,cv=RepeatedStratifiedKFold(n_splits=4, n_repeats=30, random_state=42),return_train_score=True,return_estimator=True,n_jobs=-1)
    cv_scores = pd.DataFrame({"Train": cv_model["train_score"],"Test": cv_model["test_score"]})
    plt.figure(figsize=(14, 12))
    sns.boxplot(data=cv_scores, orient='v', color='cyan', saturation=0.5)
    plt.ylabel("Recall")
    plt.title(f"Recall for Train and Test sets using 30 Repeated Stratified 4-Fold")
    plt.tight_layout()
    plt.savefig(images_path/f"cv_score_recall.png", dpi=300)
    cv_scores.to_csv(images_path/f"cv_score_recall.csv")
    plt.close()

    cv_model = cross_validate(model,X,y,scoring=accuracy_score,cv=RepeatedStratifiedKFold(n_splits=4, n_repeats=30, random_state=42),return_train_score=True,return_estimator=True,n_jobs=-1)
    cv_scores = pd.DataFrame({"Train": cv_model["train_score"],"Test": cv_model["test_score"]})
    plt.figure(figsize=(14, 12))
    sns.boxplot(data=cv_scores, orient='v', color='cyan', saturation=0.5)
    plt.ylabel("Accuracy")
    plt.title(f"Accuracy for Train and Test sets using 30 Repeated Stratified 4-Fold")
    plt.tight_layout()
    plt.savefig(images_path/f"cv_score_accuracy.png", dpi=300)
    cv_scores.to_csv(images_path/f"cv_score_accuracy.csv")
    plt.close()
    
    cv_model = cross_validate(model,X,y,scoring=jaccard_scorer,cv=RepeatedStratifiedKFold(n_splits=4, n_repeats=30, random_state=42),return_train_score=True,return_estimator=True,n_jobs=-1)
    print(cv_model)
    cv_scores = pd.DataFrame({"Train": cv_model["train_score"],"Test": cv_model["test_score"]})
    plt.figure(figsize=(14, 12))
    sns.boxplot(data=cv_scores, orient='v', color='cyan', saturation=0.5)
    plt.ylabel("Jaccard")
    plt.title(f"Jaccard for Train and Test sets using 30 Repeated Stratified 4-Fold")
    plt.tight_layout()
    plt.savefig(images_path/f"cv_score_jaccard.png", dpi=300)
    cv_scores.to_csv(images_path/f"cv_score_jaccard.csv")
    plt.close()




def summary_plot(X, model, shap_values, images_path):
    logger.info("SHAP Summary Plot.")
    damage_idx = model.classes_.searchsorted(1)
     # It should always be 1
    shap.summary_plot(
        shap_values[damage_idx],
        features=X,cmap='viridis',
        max_display=X.shape[1],
        show=False
    )

    fig = plt.gcf()
    #fig.suptitle(
     #   f"SHAP Summary Plot for LightGBM binary model.",
      #  fontsize=12)
    plt.tight_layout()
    plt.savefig(images_path / f"shap_summary.jpg", dpi=300)
    #plt.show()
    plt.close()

def waterfall_plot(X, model, shap_values, images_path):
    logger.info("SHAP Waterfall Plot.")
    damage_idx = model.classes_.searchsorted(1)  # It should always be 1

    shap.plots.waterfall(shap_values[0])
    shap.waterfall_plot(
        shap_values[damage_idx],
        features=X,
        # feature_names=#TODO,
        max_display=X.shape[1],
        show=False
    )

    fig = plt.gcf()
    fig.suptitle(
        f"SHAP Waterfall Plot for LightGBM binary model.",
        fontsize=12
    )
    plt.tight_layout()
    plt.savefig(images_path / f"shap_waterfall.png", dpi=300)
    #plt.show()
    plt.close()



def dependence_plot(X, X_display, model, shap_values, images_path):
    damage_idx = model.classes_.searchsorted(1)
    for col in X.columns:
        logger.info(f"SHAP Depence Plot for {col}")
        fig, ax = plt.subplots(figsize=(10, 7))
        X.to_csv(images_path /'X.csv',index=False)
        X_display.to_csv(images_path /'X_display.csv',index=False)
        with open(images_path / f"shap_dependence_data_{col}.pickle", 'wb') as f:
            # Pickle the 'data' dictionary using the highest protocol available.
            pickle.dump(shap_values[damage_idx], f )

        shap.dependence_plot(
            ind=col,
            shap_values=shap_values[damage_idx],
            features=X,
            display_features=X_display,
            interaction_index=None,
            # title=model.classes_[damage_idx],
            ax=ax,
            show=False
        )
        fig.suptitle(
            f"SHAP dependence plot for '{col}' feature",
            fontsize=12
        )
        fig.tight_layout()
        fig.savefig(images_path / f"shap_dependence_{col}.png", dpi=300)
        plt.close()
